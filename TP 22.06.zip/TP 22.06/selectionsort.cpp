#include <iostream>
using namespace std;

void selectionSort(int* lista, int n) {
    for (int i = 0; i < n - 1; i++) {
        int min = i;

        for (int x = i + 1; x < n; x++) {
            if (lista[x] < lista[min]) min = x;
        }

        int temp = lista[i];
        lista[i] = lista[min];
        lista[min] = temp;
    }
}

int main(int argc, char **argv)
{
    int numeros[8] = {10,20,98,34,43,12,56,87};
    cout << "Lista Desorganizada: ";
    for (int i = 0; i < 8; i++)
    {
        cout << numeros[i] << " ";
    }

    selectionSort(numeros, 8);
    cout << "\nLista Organizada: ";
    for (int i = 0; i < 8; i++)
    {
        cout << numeros[i] << " ";
    }
    

    return 0;
}