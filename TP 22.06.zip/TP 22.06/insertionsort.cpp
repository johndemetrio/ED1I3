#include <iostream>
using namespace std;

void insertionSort(int* lista, int n) {
    for (int i = 1; i < n; i++) {
        int auxiliar = lista[i];
        int x = i - 1;

        while (x >= 0 && lista[x] > auxiliar) {
            lista[x + 1] = lista[x];
            x--;
        }

        lista[x + 1] = auxiliar;
    }
}


int main(int argc, char **argv)
{
    int numeros[8] = {10,20,98,34,43,12,56,87};
    cout << "Lista Desorganizada: ";
    for (int i = 0; i < 8; i++) {
        cout << numeros[i] << " ";
    }
    insertionSort(numeros, 8);
    cout << "\nLista organizada: ";
    for (int i = 0; i < 8; i++) {
        cout << numeros[i] << " ";
    }
    
    return 0;
}